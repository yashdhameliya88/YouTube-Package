<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Technical House</title>
</head>
<body>
<?php include("header.php");?>
    <div>
        <b>
            <h1 class="text-gray-700 body-font" style="background-color: #d7d7d7; text-align:center;padding:250px;">INVALID REQUEST...</h1>
        </b>
    </div>
    
<?php
include("footer.php");
?>
</body>
</html>